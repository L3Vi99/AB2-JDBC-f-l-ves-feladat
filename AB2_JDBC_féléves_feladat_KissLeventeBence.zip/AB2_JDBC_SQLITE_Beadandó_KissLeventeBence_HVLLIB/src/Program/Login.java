package Program;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.JCheckBox;
import javax.swing.JPasswordField;
import java.awt.Color;

public class Login extends JDialog {

	private final JPanel contentPanel = new JPanel();
	DbMethods dbm = new DbMethods();
	private JTextField username;
	private JPasswordField pwd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Login dialog = new Login();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Login() {
		setBounds(100, 100, 575, 395);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(192, 192, 192));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JButton btnLogin = new JButton("Bejelentkez\u00E9s");
		btnLogin.setBackground(new Color(169, 169, 169));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.Reg1();
				int pc = dbm.Login(RTF(username), RTF(pwd));
				if(pc==1) {
					ABKezeloProg abkezel = new ABKezeloProg(Login.this);
					abkezel.setVisible(true);
					dispose();
				}
				else {
					SM("Sikertelen bejelentkez�s");
					System.exit(0);
				}
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnLogin.setBounds(181, 269, 205, 60);
		contentPanel.add(btnLogin);
		
		JLabel lblNewLabel = new JLabel("Felhaszn\u00E1l\u00F3n\u00E9v");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(181, 45, 205, 32);
		contentPanel.add(lblNewLabel);
		
		JLabel lblJelsz = new JLabel("Jelsz\u00F3");
		lblJelsz.setHorizontalAlignment(SwingConstants.CENTER);
		lblJelsz.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblJelsz.setBounds(181, 133, 205, 32);
		contentPanel.add(lblJelsz);
		
		username = new JTextField();
		username.setHorizontalAlignment(SwingConstants.CENTER);
		username.setBounds(164, 77, 247, 26);
		contentPanel.add(username);
		username.setColumns(10);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Jelsz\u00F3 l\u00E1that\u00F3s\u00E1g");
		chckbxNewCheckBox.setBackground(Color.LIGHT_GRAY);
		chckbxNewCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxNewCheckBox.isSelected()) {
					pwd.setEchoChar((char)0);
				} else {
					pwd.setEchoChar('*');
				}
			}
		});
		chckbxNewCheckBox.setBounds(224, 193, 127, 21);
		
		contentPanel.add(chckbxNewCheckBox);
		
		pwd = new JPasswordField();
		pwd.setHorizontalAlignment(SwingConstants.CENTER);
		pwd.setBounds(166, 163, 246, 22);
		contentPanel.add(pwd);
		
		setTitle("Login");
		
	}
	
	public String RTF(JTextField jtf) {
		return jtf.getText();
	}
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}
}

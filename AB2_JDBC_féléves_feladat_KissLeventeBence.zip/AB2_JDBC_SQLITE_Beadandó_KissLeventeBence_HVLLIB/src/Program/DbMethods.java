package Program;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Formatter;

import javax.swing.JOptionPane;

public class DbMethods {
	private Statement s = null;
	private Connection conn = null;
	private ResultSet rs = null;
	private PreparedStatement ps = null;
	private Formatter x;

	// Kapcsol�d�s
	public void Connect() {
		try {
			String url = "jdbc:sqlite:src/beadandodb.db";
			conn = DriverManager.getConnection(url);
		} catch (SQLException e) {
			SM("JDBC Connect: " + e.getMessage());
		}
	}

	// Lekapcsol�d�s
	public void DisConnect() {
		try {
			conn.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}

	// Driver Regiszt�r�l�s gombhoz
	public void Reg() {
		try {
			Class.forName("org.sqlite.JDBC");
			SM("Sikeres driver regisztr�ci�!");
		} catch (ClassNotFoundException e) {
			SM("Hib�s driver regisztr�ci�!" + e.getMessage());
		}
	}

	// Driver Regiszt�r�l�s
	public void Reg1() {
		try {
			Class.forName("org.sqlite.JDBC");
		} catch (ClassNotFoundException e) {
			SM("Hib�s driver regisztr�ci�!" + e.getMessage());
		}
	}

	// �zenet ki�rat�
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}

	// Bejelentkez�s
	public int Login(String name, String pswd) {
		Connect();
		int pc = -1;
		String sql = "select count(*) pc from Users where name='" + name + "' and pswd='" + pswd + "';";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				pc = rs.getInt("pc");
			}
			rs.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
		DisConnect();
		return pc;
	}

	// Tagok kiolvas�sa
	public TagTM ReadAllDataTag() {
		Object tagtmn[] = { "Jel", "K�d", "N�v", "Telefonsz�m", "C�m", "Sz�let�si id�" };
		TagTM ttm = new TagTM(tagtmn, 0);
		String nev = "", telszm = "", cim = "", sz�lido = "";
		int tid = 0;
		String sql = "Select * from Tagok";
		Connect();
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				tid = rs.getInt("tid");
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				cim = rs.getString("cim");
				sz�lido = rs.getString("sz�lido");
				ttm.addRow(new Object[] { false, tid, nev, telszm, cim, sz�lido });
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		DisConnect();
		return ttm;
	}

	// K�nyvek kiolvas�sa
	public KonyvTM ReadAllDataKonyv() {
		Object konyvtmn[] = { "Jel", "K�d", "C�m", "Szerz�", "Megjelen�s D�tuma", "Tagok akin�l a k�nyv van" };
		KonyvTM ktm = new KonyvTM(konyvtmn, 0);
		String cim = "", szerzo = "", mdatum = "";
		int kid = 0, tid = 0;
		String sql = "Select * from K�nyv";
		Connect();
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				cim = rs.getString("cim");
				szerzo = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt("tid");
				ktm.addRow(new Object[] { false, kid, cim, szerzo, mdatum, tid });
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		DisConnect();
		return ktm;
	}

	// Tagok t�rl�se
	public void DeleteTag(String tid) {
		String sql = "delete from Tagok where tid=" + tid;
		try {
			s = conn.createStatement();
			s.execute(sql);
		} catch (Exception e) {
			SM("JDBC delete: " + e.getMessage());
		}
	}

	// K�nyv t�rl�se
	public void DeleteKonyv(String kid) {
		String sql = "delete from K�nyv where kid=" + kid;
		try {
			s = conn.createStatement();
			s.execute(sql);
		} catch (Exception e) {
			SM("JDBC delete: " + e.getMessage());
		}
	}

	// Tagok modos�t�sa
	public void UpdateTag(String tid, String nev, String telszm, String cim, String sz�lido) {
		Connect();
		String sql = "update Tagok set nev= '" + nev + "', telszm= '" + telszm + "', cim= '" + cim + "', sz�lido= '"
				+ sz�lido + "' where tid='" + tid + "'";
		try {
			s = conn.createStatement();
			s.execute(sql);
			SM("Sikeres m�dos�t�s!");
		} catch (Exception e) {
			SM("JDBC Udpate: " + e.getMessage());
		}
		DisConnect();
	}

	// K�nyv modos�t�sa
	public void UpdateKonyv(String kid, String cim, String szerzo, String mdatum, String tid) {
		Connect();
		String sql = "update K�nyv set cim= '" + cim + "', szerzo= '" + szerzo + "', mdatum= '" + mdatum + "', tid= '"
				+ tid + "' where kid='" + kid + "'";
		try {
			s = conn.createStatement();
			s.execute(sql);
			SM("Sikeres m�dos�t�s!");
		} catch (Exception e) {
			SM("JDBC Udpate: " + e.getMessage());
		}
		DisConnect();
	}

	// F�jl megnyit�sa
	public void openFile(String txtName) {
		try {
			x = new Formatter(txtName);
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}

	// F�jl Bez�r�sa
	public void closeFile() {
		x.close();
	}

	// Tagok.txt felt�lt�se
	public void addRecordsTag() {
		String nev = "", telszm = "", cim = "", sz�lido = "";
		int tid = 0;
		String sql = "Select * from Tagok";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				tid = rs.getInt("tid");
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				cim = rs.getString("cim");
				sz�lido = rs.getString("sz�lido");
				x.format(tid + ";" + nev + ";" + telszm + ";" + cim + ";" + sz�lido + "\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}

	// Tagok bet�lt�se txt-b�l
	public void ReplaceDataTag(String file) {
		String sql = "";
		Connect();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String sf = in.readLine();
			sf = in.readLine();
			while (sf != null) {
				String[] st = sf.split(";");
				sql = "replace into Tagok values(" + st[0] + ", '" + st[1] + "', '" + st[2] + "', '" + st[3] + "', '"
						+ st[4] + "')";
				s = conn.createStatement();
				s.execute(sql);
				sf = in.readLine();
			}
			in.close();
			SM("Adatok bet�ltve!");
		} catch (IOException | SQLException e) {
			SM("ReplaceData: " + e.getMessage());
		}
	}

	// Konyvek.txt felt�lt�se
	public void addRecordsKonyv() {
		String cim = "", szerzo = "", mdatum = "";
		int kid = 0, tid = 0;
		String sql = "Select * from K�nyv";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				cim = rs.getString("cim");
				szerzo = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt("tid");
				x.format(kid + ";" + cim + ";" + szerzo + ";" + mdatum + ";" + tid + "\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}

	// Konyvek bet�lt�se txt-b�l
	public void ReplaceDataKonyv(String file) {
		String sql = "";
		Connect();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String sf = in.readLine();
			sf = in.readLine();
			while (sf != null) {
				String[] st = sf.split(";");
				sql = "replace into K�nyv values(" + st[0] + ", '" + st[1] + "', '" + st[2] + "', '" + st[3] + "', '"
						+ st[4] + "')";
				s = conn.createStatement();
				s.execute(sql);
				sf = in.readLine();
			}
			in.close();
			SM("Adatok bet�ltve!");
		} catch (IOException | SQLException e) {
			SM("ReplaceData: " + e.getMessage());
		}
	}

	// Tagok k�djai a leg�rd�l� ablakokhoz
	public ArrayList<String> readtid() {
		String sql = "Select tid from Tagok";
		ArrayList<String> tidStr = new ArrayList<String>();
		tidStr.add("V�lassz!");
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				tidStr.add(rs.getString("tid"));
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return tidStr;
	}

	public AllTM ReadAllData() {
		Object alltmn[] = { "Jel", "K�d", "C�m", "Szerz�", "Megjel. D�tum", "Tag ID", "N�v", "Telefonsz�m", "C�m",
				"Sz�l. id�" };
		AllTM atm = new AllTM(alltmn, 0);
		String nev = "", telszm = "", tcim = "", sz�lido = "";
		int tid = 0;
		String szerzo = "", mdatum = "", kcim = "";
		int kid = 0;
		Connect();
		String sql = "Select * from K�nyv k left join Tagok t on k.tid = t.tid";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				kcim = rs.getString(2);
				szerzo = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt(5);
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				tcim = rs.getString(9);
				sz�lido = rs.getString("sz�lido");
				atm.addRow(new Object[] { false, kid, kcim, szerzo, mdatum, tid, nev, telszm, tcim, sz�lido });
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		DisConnect();
		return atm;
	}

	// T�bl�k nev�nek lek�r�se
	public void getTables() {
		Connect();
		try {
			int i = 1;
			DatabaseMetaData metaData = conn.getMetaData();
			String[] types = { "TABLE" };
			ResultSet tables = metaData.getTables(null, null, "%", types);
			while (tables.next()) {
				SM(i + ". t�bla neve: " + tables.getString("TABLE_NAME"));
				i++;
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
		DisConnect();
	}

	// TAg felv�tel
	public void InsertTag(String tid, String nev, String telszm, String cim, String sz�lido) {
		Connect();
		String sql = "insert into Tagok values (" + tid + ", '" + nev + "', '" + telszm + "', '" + cim + "', '"
				+ sz�lido + "')";
		try {
			s = conn.createStatement();
			s.executeUpdate(sql);
			SM("Insert OK!");
		} catch (SQLException e) {
			SM("JDBC insert: " + e.getMessage());
		}
		DisConnect();
	}

	// K�nyv felv�tel
	public void InsertKonyv(String kid, String cim, String szerzo, String mdatum, String tid) {
		Connect();
		String sql = "insert into K�nyv values (" + kid + ", '" + cim + "', '" + szerzo + "', '" + mdatum + "', " + tid
				+ ")";
		try {
			s = conn.createStatement();
			s.executeUpdate(sql);
			SM("Insert OK!");
		} catch (SQLException e) {
			SM("JDBC insert: " + e.getMessage());
		}
		DisConnect();
	}

	// �sszevont.txt felt�lt�se
	public void addRecordsAll() {
		String nev = "", telszm = "", tcim = "", sz�lido = "";
		int tid = 0;
		String szerzo = "", mdatum = "", kcim = "";
		int kid = 0;
		Connect();
		String sql = "Select * from K�nyv k left join Tagok t on k.tid = t.tid";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				kcim = rs.getString(2);
				szerzo = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt(5);
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				tcim = rs.getString(9);
				sz�lido = rs.getString("sz�lido");
				x.format(kid + ";" + kcim + ";" + szerzo + ";" + mdatum + ";" + tid + ";" + nev + ";" + telszm + ";"
						+ tcim + ";" + sz�lido + "\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}

	// Sz�r�1
	public Szuro1TM ReadDataSzuro1(String varos) {
		Object sz1tmn[] = { "Jel", "K�d", "N�v", "Telefonsz�m", "C�m", "Sz�let�si id�" };
		Szuro1TM sz1tm = new Szuro1TM(sz1tmn, 0);
		String nev = "", telszm = "", cim = "", sz�lido = "";
		int tid = 0, db = 0;
		String sql = "Select * from Tagok where cim like '" + varos + "%" + "'";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				tid = rs.getInt("tid");
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				cim = rs.getString("cim");
				sz�lido = rs.getString("sz�lido");
				sz1tm.addRow(new Object[] { false, tid, nev, telszm, cim, sz�lido });
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		if (db == 0) {
			tid = 0;
			nev = "Hib�s adat";
			telszm = "";
			cim = "";
			sz�lido = "";
			sz1tm.addRow(new Object[] { false, tid, nev, telszm, cim, sz�lido });
		}
		return sz1tm;
	}

	// Sz�r�2
	public Szuro2TM ReadDataSzuro2(String alsohatar, String felsohatar) {
		Object sz2tmn[] = { "Jel", "K�d", "N�v", "Telefonsz�m", "C�m", "Sz�let�si id�" };
		Szuro2TM sz2tm = new Szuro2TM(sz2tmn, 0);
		String nev = "", telszm = "", cim = "", sz�lido = "";
		int tid = 0, db = 0;
		String sql = "Select * from Tagok where sz�lido between '" + alsohatar + "' and '" + felsohatar + "'";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				tid = rs.getInt("tid");
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				cim = rs.getString("cim");
				sz�lido = rs.getString("sz�lido");
				sz2tm.addRow(new Object[] { false, tid, nev, telszm, cim, sz�lido });
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return sz2tm;
	}

	// Sz�r�3
	public Szuro3TM ReadDataSzuro3(String szerzo) {
		Object sz3tmn[] = { "Jel", "K�d", "C�m", "Szerz�", "Megjelen�s D�tuma", "Tagok akin�l a k�nyv van" };
		Szuro3TM sz3tm = new Szuro3TM(sz3tmn, 0);
		String cim = "", szerz = "", mdatum = "";
		int kid = 0, tid = 0, db = 0;
		String sql = "Select * from K�nyv where szerzo like '" + szerzo + "%" + "'";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				cim = rs.getString("cim");
				szerz = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt("tid");
				sz3tm.addRow(new Object[] { false, kid, cim, szerz, mdatum, tid });
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		if (db == 0) {
			kid = 0;
			cim = "";
			szerz = "Hib�s adat";
			mdatum = "";
			tid = 0;
			sz3tm.addRow(new Object[] { false, kid, cim, szerz, mdatum, tid });
		}
		return sz3tm;
	}

	// Sz�r�4
	public Szuro4TM ReadDataSzuro4(String alsohatar, String felsohatar) {
		Object sz4tmn[] = { "Jel", "K�d", "C�m", "Szerz�", "Megjelen�s D�tuma", "Tagok akin�l a k�nyv van" };
		Szuro4TM sz4tm = new Szuro4TM(sz4tmn, 0);
		String cim = "", szerzo = "", mdatum = "";
		int kid = 0, tid = 0, db = 0;
		String sql = "Select * from K�nyv where mdatum between '" + alsohatar + "' and '" + felsohatar + "'";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				cim = rs.getString("cim");
				szerzo = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt("tid");
				sz4tm.addRow(new Object[] { false, kid, cim, szerzo, mdatum, tid });
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		if (db == 0) {
			kid = 0;
			cim = "";
			szerzo = "";
			mdatum = "Hib�s adat";
			tid = 0;
			sz4tm.addRow(new Object[] { false, kid, cim, szerzo, mdatum, tid });
		}
		return sz4tm;
	}

	// Sz�r�5
	public Szuro5TM ReadDataSzuro5(String tagnev) {
		Object sz5tmn[] = { "Jel", "K�d", "C�m", "Szerz�" };
		Szuro5TM sz5tm = new Szuro5TM(sz5tmn, 0);
		String cim = "", szerzo = "";
		int kid = 0, db = 0;
		String sql = "Select kid, k.cim, szerzo from K�nyv k inner join Tagok t on t.tid=k.tid where t.nev = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, tagnev);
			rs = ps.executeQuery();
			while (rs.next()) {
				kid = rs.getInt("kid");
				cim = rs.getString("cim");
				szerzo = rs.getString("szerzo");
				sz5tm.addRow(new Object[] { false, kid, cim, szerzo });
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		if (db == 0) {
			kid = 0;
			cim = "";
			szerzo = "Hib�s adat";
			sz5tm.addRow(new Object[] { false, kid, cim, szerzo });
		}

		return sz5tm;
	}

}

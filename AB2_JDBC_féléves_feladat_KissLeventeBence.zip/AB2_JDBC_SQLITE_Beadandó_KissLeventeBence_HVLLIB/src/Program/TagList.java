package Program;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import java.awt.Font;
import java.awt.Color;

public class TagList extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private TagTM ttm;
	DbMethods dbm = new DbMethods();

	public TagList(JFrame f,TagTM betm) {
		super(f, "Tagok list�ja", true);
		ttm =betm;
		setBounds(100, 100, 670, 360);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton btnNewButton = new JButton("Bez\u00E1r");
			btnNewButton.setBackground(new Color(169, 169, 169));
			btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnNewButton.setBounds(542, 280, 104, 33);
			contentPanel.add(btnNewButton);
		}
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 636, 260);
		contentPanel.add(scrollPane);
		
		table = new JTable(ttm);
		scrollPane.setViewportView(table);
		
		TableColumn tc = null;
		for (int i = 0; i < 6; i++) {
		tc = table.getColumnModel().getColumn(i);
		if (i==0 || i==1 ) tc.setPreferredWidth(20);
		else if (i==4) tc.setPreferredWidth(180);
		else {tc.setPreferredWidth(100);}
		}
		
		table.setAutoCreateRowSorter(true);
		
		JButton btnTorol = new JButton("T\u00F6rl\u00E9s");
		btnTorol.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int db=0,jel=0,x=0;
				for (x = 0; x < ttm.getRowCount(); x++)
					if((Boolean)ttm.getValueAt(x, 0)) {db++; jel=x;}
				if(db==0) SM("Nincs kijel�lve semmi");
				if(db>1) SM("Egyszerre csak egy t�r�lhet�");
				if(db==1) {
					dbm.Connect();
					dbm.DeleteTag(RTM(jel,1));
					ttm.removeRow(jel);
					dbm.DisConnect();
				}
			}
		});
		btnTorol.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnTorol.setBackground(new Color(169, 169, 169));
		btnTorol.setBounds(10, 280, 104, 33);
		contentPanel.add(btnTorol);
		
		JButton btnModosts = new JButton("Modos\u00EDt\u00E1s");
		btnModosts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int db=0, jel=0, x=0;
				for (x = 0; x <ttm.getRowCount(); x++) 
					if((Boolean)ttm.getValueAt(x, 0)) {db++; jel=x;}
				if(db==0) SM("V�lasszon ki egy rekordot");
				if(db>1) SM("Maximum egy rekordot lehet kiv�lasztani");
				if(db==1) {
					ModTag mt = new ModTag(null, RTM(jel,1), RTM(jel,2), RTM(jel,3),  RTM(jel,4),  RTM(jel,5));
					mt.setVisible(true);
				}
			}
		});
		btnModosts.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnModosts.setBackground(new Color(169, 169, 169));
		btnModosts.setBounds(124, 280, 104, 33);
		contentPanel.add(btnModosts);
		
		JButton btnMents = new JButton("Ment\u00E9s");
		btnMents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					dbm.Connect();
					dbm.openFile("Tagok.txt");
					dbm.addRecordsTag();
					dbm.closeFile();
					dbm.DisConnect();
					SM("Sikeres ki�r�s! A file megtal�lhat� Tagok.txt n�ven");
				} catch (Exception e2) {
					SM("Sikertelen k��r�s: "+e2.getMessage());
				}
			}
		});
		btnMents.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnMents.setBackground(new Color(169, 169, 169));
		btnMents.setBounds(238, 280, 104, 33);
		contentPanel.add(btnMents);
		
		JButton btnBetlts = new JButton("Bet\u00F6lt\u00E9s");
		btnBetlts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.ReplaceDataTag("Tagok.txt");
			}
		});
		btnBetlts.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnBetlts.setBackground(new Color(169, 169, 169));
		btnBetlts.setBounds(352, 280, 104, 33);
		contentPanel.add(btnBetlts);
		TableRowSorter<TagTM> trs =
		(TableRowSorter<TagTM>)table.getRowSorter();
		trs.setSortable(0, false);

		
	}
	
	public String RTM(int row,int col) {
		return ttm.getValueAt(row, col).toString();
	}
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}

}

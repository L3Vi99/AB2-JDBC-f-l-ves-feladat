package Program;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class KonyvList extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private KonyvTM ktm;
	DbMethods dbm = new DbMethods();

	public KonyvList(JFrame f,KonyvTM betm) {
		super(f, "K�nyvek list�ja", true);
		ktm =betm;
		setBounds(100, 100, 670, 360);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(192, 192, 192));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton btnNewButton = new JButton("Bez\u00E1r");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnNewButton.setBackground(new Color(169, 169, 169));
			btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
			btnNewButton.setBounds(552, 293, 94, 30);
			contentPanel.add(btnNewButton);
		}
		{
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(10, 10, 636, 273);
			contentPanel.add(scrollPane);
			{
				table = new JTable(ktm);
				
				scrollPane.setViewportView(table);
				
				TableColumn tc = null;
				for (int i = 0; i < 6; i++) {
				tc = table.getColumnModel().getColumn(i);
				if (i==0 || i==1 ) tc.setPreferredWidth(20);
				else if (i==2 ||i==3) tc.setPreferredWidth(180);
				else if (i==4 ) tc.setPreferredWidth(80);
				else {tc.setPreferredWidth(100);}
				}
				
				table.setAutoCreateRowSorter(true);
				{
					JButton btnTrls = new JButton("T\u00F6rl\u00E9s");
					btnTrls.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							int db=0,jel=0,x=0;
							for (x = 0; x < ktm.getRowCount(); x++)
								if((Boolean)ktm.getValueAt(x, 0)) {db++; jel=x;}
							if(db==0) SM("Nincs kijel�lve semmi");
							if(db>1) SM("Egyszerre csak egy t�r�lhet�");
							if(db==1) {
								dbm.Connect();
								dbm.DeleteKonyv(RTM(jel,1));
								ktm.removeRow(jel);
								dbm.DisConnect();
							}
						}
					});
					btnTrls.setFont(new Font("Tahoma", Font.PLAIN, 12));
					btnTrls.setBackground(new Color(169, 169, 169));
					btnTrls.setBounds(10, 293, 94, 30);
					contentPanel.add(btnTrls);
				}
				{
					JButton btnModosts = new JButton("M\u00F3dos\u00EDt\u00E1s");
					btnModosts.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							int db=0, jel=0, x=0;
							for (x = 0; x <ktm.getRowCount(); x++) 
								if((Boolean)ktm.getValueAt(x, 0)) {db++; jel=x;}
							if(db==0) SM("V�lasszon ki egy rekordot");
							if(db>1) SM("Maximum egy rekordot lehet kiv�lasztani");
							if(db==1) {
								ModKonyv mt = new ModKonyv(null, RTM(jel,1), RTM(jel,2), RTM(jel,3),  RTM(jel,4),  RTM(jel,5));
								mt.setVisible(true);
							}
						}
					});
					btnModosts.setFont(new Font("Tahoma", Font.PLAIN, 12));
					btnModosts.setBackground(new Color(169, 169, 169));
					btnModosts.setBounds(114, 293, 94, 30);
					contentPanel.add(btnModosts);
				}
				{
					JButton btnMents = new JButton("Ment\u00E9s");
					btnMents.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							try {
								dbm.Connect();
								dbm.openFile("Konyvek.txt");
								dbm.addRecordsKonyv();
								dbm.closeFile();
								dbm.DisConnect();
								SM("Sikeres ki�r�s! A file megtal�lhat� Konyvek.txt n�ven");
							} catch (Exception e2) {
								SM("Sikertelen k��r�s: "+e2.getMessage());
							}
						}
					});
					btnMents.setFont(new Font("Tahoma", Font.PLAIN, 12));
					btnMents.setBackground(new Color(169, 169, 169));
					btnMents.setBounds(218, 293, 94, 30);
					contentPanel.add(btnMents);
				}
				{
					JButton btnBetlts = new JButton("Bet\u00F6lt\u00E9s");
					btnBetlts.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							dbm.ReplaceDataKonyv("Konyvek.txt");
						}
					});
					btnBetlts.setFont(new Font("Tahoma", Font.PLAIN, 12));
					btnBetlts.setBackground(new Color(169, 169, 169));
					btnBetlts.setBounds(322, 293, 94, 30);
					contentPanel.add(btnBetlts);
				}
				TableRowSorter<KonyvTM> trs =
						(TableRowSorter<KonyvTM>)table.getRowSorter();
				trs.setSortable(0, false);

			}
		}
		
		
	}
	
	public String RTM(int row,int col) {
		return ktm.getValueAt(row, col).toString();
	}
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}

}

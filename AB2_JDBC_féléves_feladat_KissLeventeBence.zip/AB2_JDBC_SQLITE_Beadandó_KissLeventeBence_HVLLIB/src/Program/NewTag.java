package Program;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.util.Date;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NewTag extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField tid;
	private JTextField nev;
	private JTextField telszm;
	private JTextField cim;
	private JTextField sz�lido;
	DbMethods dbm = new DbMethods();

	public NewTag(JFrame f) {
		super(f,"�j tag felv�tele", true);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(192, 192, 192));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("K\u00F3d:");
			lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblNewLabel.setBounds(10, 10, 122, 26);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNv = new JLabel("N\u00E9v:");
			lblNv.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblNv.setBounds(10, 46, 122, 26);
			contentPanel.add(lblNv);
		}
		{
			JLabel lblTelefonszm = new JLabel("Telefonsz\u00E1m:");
			lblTelefonszm.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblTelefonszm.setBounds(10, 82, 122, 26);
			contentPanel.add(lblTelefonszm);
		}
		{
			JLabel lblCm = new JLabel("C\u00EDm:");
			lblCm.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblCm.setBounds(10, 118, 122, 26);
			contentPanel.add(lblCm);
		}
		{
			JLabel lblSzletsiId = new JLabel("Sz\u00FClet\u00E9si id\u0151:");
			lblSzletsiId.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblSzletsiId.setBounds(10, 154, 122, 26);
			contentPanel.add(lblSzletsiId);
		}
		{
			tid = new JTextField();
			tid.setBounds(142, 13, 107, 25);
			contentPanel.add(tid);
			tid.setColumns(10);
		}
		{
			nev = new JTextField();
			nev.setColumns(10);
			nev.setBounds(142, 46, 233, 25);
			contentPanel.add(nev);
		}
		{
			telszm = new JTextField();
			telszm.setColumns(10);
			telszm.setBounds(142, 82, 160, 25);
			contentPanel.add(telszm);
		}
		{
			cim = new JTextField();
			cim.setColumns(10);
			cim.setBounds(142, 118, 233, 25);
			contentPanel.add(cim);
		}
		{
			JButton btnNewButton = new JButton("Felv\u00E9tel");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(!filledTF(tid)) SM("A k�d mez� �res");
					else if(!goodInt(tid)) SM("A k�d mez� nem helyes");
					else if(!filledTF(nev)) SM("A n�v mez� �res");
					else if(!filledTF(telszm)) SM("A telefonsz�m mez� �res");
					else if(!filledTF(cim)) SM("A c�m mez� �res");
					else if(!filledTF(sz�lido)) SM("A sz�let�si id� mez� �res");
					else if(!goodDate(sz�lido)) SM("A sz�let�si id� helytelen");
					else {
					dbm.InsertTag(RTF(tid), RTF(nev), RTF(telszm), RTF(cim), RTF(sz�lido));
					dispose();
					}
				}
			});
			btnNewButton.setBackground(new Color(169, 169, 169));
			btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
			btnNewButton.setBounds(245, 199, 130, 40);
			contentPanel.add(btnNewButton);
		}
		{
			sz�lido = new JTextField();
			sz�lido.setColumns(10);
			sz�lido.setBounds(142, 154, 107, 25);
			contentPanel.add(sz�lido);
		}
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Hiba �zenet", 2);
	}
	
	public String RTF(JTextField jtf) {
		return jtf.getText();
	}
	
	public boolean filledTF(JTextField jtf) {
		String s = RTF(jtf);
		if(s.length()>0) return true;
		return false;
	}
	
	public boolean goodDate(JTextField jtf) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		String s = RTF(jtf);
		Date testDate = null;
		try {
			testDate = sdf.parse(s);
		} catch (ParseException e) {return false;}
		if(sdf.format(testDate).equals(s)) return true;
		else return false;
	}
	
	public boolean goodInt(JTextField jtf) {
		String s = RTF(jtf);
		try {
			Integer.parseInt(s); return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

}
